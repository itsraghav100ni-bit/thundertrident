package me.thunder.trident;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class ThunderTrident extends JavaPlugin implements Listener {

    private NamespacedKey key;
    private final Map<UUID, Long> boomCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        key = new NamespacedKey(this, "thunder");
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ThunderTrident enabled.");
    }

    // ---------------------------------------------------------------- item

    private ItemStack createTrident() {
        ItemStack item = new ItemStack(Material.TRIDENT);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Thunder Trident", NamedTextColor.GOLD, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Lightning follows every throw", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Sneak + throw: Sonic Boom", NamedTextColor.AQUA)
                        .decoration(TextDecoration.ITALIC, false)));
        meta.addEnchant(Enchantment.LOYALTY, getConfig().getInt("loyalty-level", 10), true);
        meta.addEnchant(Enchantment.FLAME, 1, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.setUnbreakable(true);
        if (getConfig().getBoolean("use-custom-model", false)) {
            meta.setItemModel(new NamespacedKey("thundertrident", "thunder_trident"));
        }
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isThunder(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    // -------------------------------------------------------------- launch

    @EventHandler
    public void onLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof Trident trident)) return;
        if (!(trident.getShooter() instanceof Player player)) return;
        if (!isThunder(trident.getItemStack())) return;

        startFlightEffects(trident);
        if (player.isSneaking()) {
            sonicBoom(player);
        }
    }

    private void startFlightEffects(Trident trident) {
        final int interval = Math.max(1, getConfig().getInt("flight-lightning-interval-ticks", 2));
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!trident.isValid() || ticks > 1200) {
                    cancel();
                    return;
                }
                Location l = trident.getLocation();
                World w = l.getWorld();
                w.spawnParticle(Particle.ELECTRIC_SPARK, l, 8, 0.3, 0.3, 0.3, 0.1);
                w.spawnParticle(Particle.END_ROD, l, 2, 0.1, 0.1, 0.1, 0.02);
                w.spawnParticle(Particle.FLAME, l, 3, 0.15, 0.15, 0.15, 0.01);
                if (ticks % interval == 0) {
                    w.strikeLightningEffect(l);
                }
                ticks++;
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    // ----------------------------------------------------------------- hit

    @EventHandler
    public void onHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Trident trident)) return;
        if (!isThunder(trident.getItemStack())) return;

        final Location center = event.getHitEntity() != null
                ? event.getHitEntity().getLocation()
                : trident.getLocation();
        final World world = center.getWorld();
        final Player thrower = trident.getShooter() instanceof Player p ? p : null;

        // Flame: set the hit mob on fire
        if (event.getHitEntity() instanceof LivingEntity le && le != thrower) {
            le.setFireTicks(getConfig().getInt("flame-seconds", 10) * 20);
        }

        // Impact animation
        world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 1);
        world.spawnParticle(Particle.ELECTRIC_SPARK, center, 120, 2, 1, 2, 0.3);
        world.spawnParticle(Particle.END_ROD, center, 60, 1.5, 1.5, 1.5, 0.2);
        world.spawnParticle(Particle.FLAME, center, 80, 1.5, 0.5, 1.5, 0.1);
        world.playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 4f, 0.8f);

        // Storm of real lightning, spread over a few ticks
        final int strikes = Math.max(0, Math.min(100, getConfig().getInt("impact-real-strikes", 15)));
        final double radius = getConfig().getDouble("impact-strike-radius", 6.0);
        final double safe = getConfig().getDouble("impact-safe-distance-from-thrower", 5.0);

        for (int i = 0; i < strikes; i++) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    ThreadLocalRandom rnd = ThreadLocalRandom.current();
                    double angle = rnd.nextDouble() * Math.PI * 2;
                    double dist = rnd.nextDouble() * radius;
                    Location target = center.clone().add(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
                    boolean tooClose = thrower != null
                            && thrower.getWorld().equals(world)
                            && thrower.getLocation().distance(target) < safe;
                    if (tooClose) {
                        world.strikeLightningEffect(target);
                    } else {
                        world.strikeLightning(target);
                    }
                }
            }.runTaskLater(this, i);
        }
    }

    // ---------------------------------------------------------- sonic boom

    private void sonicBoom(Player p) {
        long now = System.currentTimeMillis();
        long cooldown = (long) (getConfig().getDouble("sonic-boom-cooldown-seconds", 3) * 1000);
        Long last = boomCooldown.get(p.getUniqueId());
        if (last != null && now - last < cooldown) return;
        boomCooldown.put(p.getUniqueId(), now);

        double range = getConfig().getDouble("sonic-boom-range", 40.0);
        double damage = getConfig().getDouble("sonic-boom-damage", 20.0);
        World w = p.getWorld();
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();

        double dist = range;
        LivingEntity target = null;

        RayTraceResult entityHit = w.rayTraceEntities(eye.clone().add(dir), dir, range, 1.5,
                e -> e instanceof LivingEntity && !e.equals(p));
        if (entityHit != null && entityHit.getHitEntity() instanceof LivingEntity le) {
            target = le;
            dist = eye.distance(le.getLocation().add(0, le.getHeight() / 2, 0));
        }

        RayTraceResult blockHit = w.rayTraceBlocks(eye, dir, dist, FluidCollisionMode.NEVER, true);
        if (blockHit != null) {
            double d = blockHit.getHitPosition().distance(eye.toVector());
            if (d < dist) {
                dist = d;
                target = null;
            }
        }

        for (double d = 1; d < dist; d += 1.5) {
            Location point = eye.clone().add(dir.clone().multiply(d));
            w.spawnParticle(Particle.SONIC_BOOM, point, 1, 0, 0, 0, 0);
            w.spawnParticle(Particle.ELECTRIC_SPARK, point, 4, 0.2, 0.2, 0.2, 0.05);
        }
        w.playSound(eye, Sound.ENTITY_WARDEN_SONIC_BOOM, 3f, 1f);

        if (target != null) {
            Location tl = target.getLocation().add(0, target.getHeight() / 2, 0);
            w.spawnParticle(Particle.EXPLOSION, tl, 3, 0.4, 0.4, 0.4, 0);
            target.damage(damage, p);
            target.setVelocity(dir.clone().multiply(1.8).setY(0.5));
        }
    }

    // ------------------------------------------------------------- command

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("thundertrident.give")) {
            sender.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }
        Player target;
        if (args.length > 0) {
            target = getServer().getPlayerExact(args[0]);
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage("Usage: /thundertrident <player>");
            return true;
        }
        if (target == null) {
            sender.sendMessage(Component.text("Player not found.", NamedTextColor.RED));
            return true;
        }
        target.getInventory().addItem(createTrident());
        sender.sendMessage(Component.text("Gave Thunder Trident to " + target.getName(), NamedTextColor.GREEN));
        return true;
    }
}
